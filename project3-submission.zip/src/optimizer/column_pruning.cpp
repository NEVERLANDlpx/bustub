#include "optimizer/optimizer.h"

namespace bustub {

/**
 * @note You may use this function to implement column pruning optimization.
 */
auto Optimizer::OptimizeColumnPruning(const bustub::AbstractPlanNodeRef &plan) -> AbstractPlanNodeRef {
  // Your code here
  return plan;
}

}  // namespace bustub
